<?php

header("Location: ../wrong-url");
exit("Forbidden action");

?>