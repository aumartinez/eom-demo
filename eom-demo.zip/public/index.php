<?php

header("Location: ../");
exit("Forbidden action");

?>
